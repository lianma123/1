package com.winterchen.model;

public class UserDomain {
    private int click;
    private int reply;
    private String title;
    private String author;
    private String senddata;
    private String lastdata;
    private String sentiment;
    private String total;

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }

    public void setSentiment(String sentiment) {
        this.sentiment = sentiment;
    }

    public String getSentiment() {

        return sentiment;
    }

    public void setClick(int click) {
        this.click = click;
    }

    public void setReply(int reply) {
        this.reply = reply;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public void setSenddata(String senddata) {
        this.senddata = senddata;
    }

    public void setLastdata(String lastdata) {
        this.lastdata = lastdata;
    }

    public int getClick() {

        return click;
    }

    public int getReply() {
        return reply;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public String getSenddata() {
        return senddata;
    }

    public String getLastdata() {
        return lastdata;
    }
}