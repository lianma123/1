package com.winterchen.controller;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.ui.Model;
import com.github.pagehelper.PageHelper;
import com.winterchen.model.UserDomain;
import com.winterchen.service.user.UserService;
import com.winterchen.service.user.impl.UserServiceImpl;
import com.winterchen.utils.Scrap;
import com.winterchen.utils.SentimentUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
/**
 * Created by Administrator on 2017/8/16.
 */
@Controller
@RequestMapping(value = "/")
public class UserController {

    @Autowired
    private UserService userService;
    @Autowired
    private UserServiceImpl userServiceImpl;
    @RequestMapping(value = "",method = {RequestMethod.GET})
    public String hello(){
        return "index";
    }
    @RequestMapping(value = "table",method = {RequestMethod.GET})
    public String table(){
        return "table-advanced";
    }
    @RequestMapping(value = "haha",method = {RequestMethod.GET})
    public String hello1(){
        return "infolist";
    }
    @RequestMapping(value = "click", method = RequestMethod.GET)
    @ResponseBody
    public Map<String,Object> getClickList( @RequestParam(value = "name", defaultValue = "") String name)
    {
        Map<String,Object> map = new HashMap<>();
        map.put("msg", "ok");
        map.put("data", userService.findClickTop());
        System.out.println(name);
        return map;
    }
    @RequestMapping(value = "list1")
    public String list1(Model model) {
//        List<Server> users=searchFilesUtils.getFile();
        model.addAttribute("users", userService.findClickTop());
        return "table-advanced";
    }
    @RequestMapping(value = "list", method = RequestMethod.GET)
    @ResponseBody
    public Map<String,Object> getList( @RequestParam(value = "name", defaultValue = "") String name)
    {
        Map<String,Object> map = new HashMap<>();
        map.put("msg", "ok");
        map.put("data", userService.findAll());
        System.out.println(name);
        return map; }
    @RequestMapping(value = "add", method = RequestMethod.GET)
    @ResponseBody
    public void addUser(){ for(int i=1;i<430;i++){
        String url = "http://guba.eastmoney.com/type,zg80036742_"+i+".html";
        Document doc = null; try {
            UserDomain userDomain = new UserDomain();
            doc = Jsoup.connect(url).get();
            Elements elements = doc.select(".pager").select("span"); // System.out.println(elements);
            //
            Elements listDiv = doc.getElementsByAttributeValue("class", "articleh"); // System.out.println(listDiv);

        for(Element element : listDiv){

            Elements texts = element.getElementsByTag("a");
            Elements texts1 = element.select(".l6");
            Elements texts2 = element.select(".l5");
            Elements texts3 = element.select(".l4");
            Elements texts4 = element.select(".l1");
            Elements texts5 = element.select(".l2");
// System.out.println(texts1);
for(Element text:texts4){
    String ptext = text.text();
     if(ptext!="") { // System.out.print("点击："+ptext+"	");
userDomain.setClick(Integer.valueOf(ptext)); }

        }
        for(Element text:texts5){
            String ptext = text.text();
            if(ptext!="") {
// System.out.print("点击："+ptext+"	");
        userDomain.setReply(Integer.valueOf(ptext)); }

            }
            for(Element text:texts3){
                String ptext = text.text();
                if(ptext!="") {
                    userDomain.setAuthor(ptext);
                }

            }
            for(Element text:texts2){
                String ptext = text.text();
                if(ptext!="") {
                    userDomain.setLastdata(ptext);
                }

            }
            for(Element text:texts1){
                String ptext = text.text();
                if(ptext!="") {
                    userDomain.setSenddata(ptext);
                }

            }
            for(Element text:texts){
                String ptext = text.attr("title");
                if(ptext!="") {
                    userDomain.setTitle(ptext);
                    userDomain.setSentiment(SentimentUtils.sentimentJudge(ptext));

                }





            }
            userService.addUser(userDomain);
        }
    } catch (IOException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
    }

    }}
    @ResponseBody
    @GetMapping("/all")
    public Object findAllUser(
            @RequestParam(name = "pageNum", required = false, defaultValue = "1")
                    int pageNum,
            @RequestParam(name = "pageSize", required = false, defaultValue = "10")
                    int pageSize){
        return userService.findAllUser(pageNum,pageSize);
    }
}
